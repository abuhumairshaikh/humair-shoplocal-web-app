"""
Enhanced Recommendation Engine for ShopLocal
Week 4 - Advanced Features

This module provides intelligent product recommendations using:
1. Collaborative Filtering (customers who bought X also bought Y)
2. Trending Products (based on recent views and purchases)
3. Recently Viewed Products
4. Category-based recommendations
"""

from datetime import datetime, timedelta
from collections import defaultdict
import pymysql


class RecommendationEngine:

    def __init__(self, db_config):
        self.db_config = db_config

    def generate_collaborative_recommendations(self, product_id, limit=5):
        """
        Safe fallback implementation.
        Your advanced logic can replace this later.
        """
        return []

    def get_smart_recommendations(self, product_id, session_id=None, limit=5):
        """
        Smart recommendation wrapper
        """
        recommendations = self.generate_collaborative_recommendations(
            product_id=product_id,
            limit=limit
        )

        return recommendations[:limit]

    def get_recommendations(self, product_id, limit=4, session_id=None):
        """
        Public method used by Flask API
        """
        return self.get_smart_recommendations(
            product_id=product_id,
            session_id=session_id,
            limit=limit
        )

    
    def get_connection(self):
        """Get database connection"""
        return pymysql.connect(
            host=self.db_config['host'],
            user=self.db_config['user'],
            password=self.db_config['password'],
            database=self.db_config['database'],
            cursorclass=pymysql.cursors.DictCursor
        )
    
    # =========================================================================
    # COLLABORATIVE FILTERING - "Customers who bought X also bought Y"
    # =========================================================================
    
    def generate_collaborative_recommendations(self, product_id, limit=5):
        """
        Find products that customers bought together with the given product
        
        Algorithm:
        1. Find all orders that include the given product
        2. Find other products in those orders
        3. Count frequency of co-purchases
        4. Return top N products by frequency
        
        Args:
            product_id (int): Product ID to find recommendations for
            limit (int): Number of recommendations to return
            
        Returns:
            list: List of recommended product IDs with scores
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Find orders containing the given product
            cursor.execute("""
                SELECT DISTINCT order_id
                FROM order_items
                WHERE product_id = %s
            """, (product_id,))
            
            order_ids = [row['order_id'] for row in cursor.fetchall()]
            
            if not order_ids:
                return []
            
            # Find other products in those orders
            placeholders = ','.join(['%s'] * len(order_ids))
            cursor.execute(f"""
                SELECT 
                    oi.product_id,
                    p.name,
                    p.price,
                    p.image_url,
                    p.stock,
                    COUNT(*) as co_purchase_count
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id IN ({placeholders})
                    AND oi.product_id != %s
                    AND p.status = 'active'
                    AND p.stock > 0
                GROUP BY oi.product_id, p.name, p.price, p.image_url, p.stock
                ORDER BY co_purchase_count DESC
                LIMIT %s
            """, (*order_ids, product_id, limit))
            
            recommendations = cursor.fetchall()
            
            # Calculate recommendation score (0-100)
            max_count = recommendations[0]['co_purchase_count'] if recommendations else 1
            for rec in recommendations:
                rec['score'] = int((rec['co_purchase_count'] / max_count) * 100)
                rec['recommendation_type'] = 'also_bought'
            
            return recommendations
            
        finally:
            cursor.close()
            conn.close()
    
    # =========================================================================
    # TRENDING PRODUCTS
    # =========================================================================
    
    def get_trending_products(self, days=7, limit=10):
        """
        Get trending products based on recent views and purchases
        
        Trending Score = (Purchases * 10) + (Views * 1)
        Only considers activity from last N days
        
        Args:
            days (int): Number of days to look back
            limit (int): Number of products to return
            
        Returns:
            list: List of trending products with scores
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            since_date = datetime.now() - timedelta(days=days)
            
            cursor.execute("""
                SELECT 
                    p.id,
                    p.name,
                    p.price,
                    p.image_url,
                    p.category,
                    p.stock,
                    p.purchases as total_purchases,
                    p.views as total_views,
                    COUNT(DISTINCT pv.id) as recent_views,
                    COUNT(DISTINCT oi.order_id) as recent_purchases,
                    (COUNT(DISTINCT oi.order_id) * 10 + COUNT(DISTINCT pv.id)) as trending_score
                FROM products p
                LEFT JOIN product_views pv ON p.id = pv.product_id 
                    AND pv.viewed_at >= %s
                LEFT JOIN order_items oi ON p.id = oi.product_id
                LEFT JOIN orders o ON oi.order_id = o.id 
                    AND o.created_at >= %s
                WHERE p.status = 'active'
                    AND p.stock > 0
                GROUP BY p.id, p.name, p.price, p.image_url, p.category, p.stock, 
                         p.purchases, p.views
                HAVING trending_score > 0
                ORDER BY trending_score DESC
                LIMIT %s
            """, (since_date, since_date, limit))
            
            trending = cursor.fetchall()
            
            # Normalize scores to 0-100
            max_score = trending[0]['trending_score'] if trending else 1
            for product in trending:
                product['score'] = int((product['trending_score'] / max_score) * 100)
                product['recommendation_type'] = 'trending'
            
            return trending
            
        finally:
            cursor.close()
            conn.close()
    
    # =========================================================================
    # RECENTLY VIEWED PRODUCTS
    # =========================================================================
    
    def get_recently_viewed(self, session_id, limit=10):
        """
        Get recently viewed products for a session
        
        Args:
            session_id (str): Session ID
            limit (int): Number of products to return
            
        Returns:
            list: List of recently viewed products
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                SELECT DISTINCT
                    p.id,
                    p.name,
                    p.price,
                    p.image_url,
                    p.category,
                    p.stock,
                    MAX(pv.viewed_at) as last_viewed
                FROM product_views pv
                JOIN products p ON pv.product_id = p.id
                WHERE pv.session_id = %s
                    AND p.status = 'active'
                GROUP BY p.id, p.name, p.price, p.image_url, p.category, p.stock
                ORDER BY last_viewed DESC
                LIMIT %s
            """, (session_id, limit))
            
            return cursor.fetchall()
            
        finally:
            cursor.close()
            conn.close()
    
    # =========================================================================
    # CATEGORY-BASED RECOMMENDATIONS
    # =========================================================================
    
    def get_category_recommendations(self, category, exclude_product_id=None, limit=5):
        """
        Get popular products from the same category
        
        Args:
            category (str): Product category
            exclude_product_id (int): Product ID to exclude
            limit (int): Number of recommendations
            
        Returns:
            list: List of recommended products
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            query = """
                SELECT 
                    id,
                    name,
                    price,
                    image_url,
                    category,
                    stock,
                    purchases,
                    views,
                    (purchases * 2 + views) as popularity_score
                FROM products
                WHERE category = %s
                    AND status = 'active'
                    AND stock > 0
            """
            params = [category]
            
            if exclude_product_id:
                query += " AND id != %s"
                params.append(exclude_product_id)
            
            query += " ORDER BY popularity_score DESC LIMIT %s"
            params.append(limit)
            
            cursor.execute(query, params)
            
            recommendations = cursor.fetchall()
            
            # Add recommendation metadata
            for rec in recommendations:
                rec['recommendation_type'] = 'category'
                rec['score'] = 75  # Fixed score for category recommendations
            
            return recommendations
            
        finally:
            cursor.close()
            conn.close()
    
    # =========================================================================
    # SMART PRODUCT RECOMMENDATIONS (Combined Strategy)
    # =========================================================================
    
    def get_smart_recommendations(self, product_id, session_id=None, limit=5):
        """
        Get smart recommendations using multiple strategies
        
        Priority:
        1. Collaborative filtering (if available)
        2. Category-based recommendations
        3. Trending products
        
        Args:
            product_id (int): Product ID
            session_id (str): Optional session ID
            limit (int): Number of recommendations
            
        Returns:
            list: Combined recommendations
        """
        recommendations = []
        
        # Strategy 1: Collaborative filtering
        collab_recs = self.generate_collaborative_recommendations(product_id, limit=limit)
        recommendations.extend(collab_recs)
        
        # If not enough recommendations, add category-based
        if len(recommendations) < limit:
            conn = self.get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT category FROM products WHERE id = %s", (product_id,))
                result = cursor.fetchone()
                if result:
                    category = result['category']
                    remaining = limit - len(recommendations)
                    category_recs = self.get_category_recommendations(
                        category, 
                        exclude_product_id=product_id,
                        limit=remaining
                    )
                    recommendations.extend(category_recs)
            finally:
                cursor.close()
                conn.close()
        
        # If still not enough, add trending
        if len(recommendations) < limit:
            remaining = limit - len(recommendations)
            trending = self.get_trending_products(days=7, limit=remaining)
            recommendations.extend(trending)
        
        return recommendations[:limit]
    
    # =========================================================================
    # BATCH RECOMMENDATION GENERATION
    # =========================================================================
    
    def generate_all_recommendations(self):
        """
        Generate and store recommendations for all products
        This should be run periodically (e.g., daily) to pre-compute recommendations
        
        Returns:
            dict: Statistics about generated recommendations
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Clear old recommendations
            cursor.execute("DELETE FROM product_recommendations")
            conn.commit()
            
            # Get all active products
            cursor.execute("SELECT id FROM products WHERE status = 'active'")
            products = cursor.fetchall()
            
            total_recommendations = 0
            
            for product in products:
                product_id = product['id']
                
                # Generate collaborative recommendations
                collab_recs = self.generate_collaborative_recommendations(product_id, limit=10)
                
                for i, rec in enumerate(collab_recs):
                    cursor.execute("""
                        INSERT INTO product_recommendations 
                        (product_id, recommended_product_id, score, recommendation_type, rank)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (product_id, rec['product_id'], rec['score'], 
                          rec['recommendation_type'], i + 1))
                    total_recommendations += 1
            
            conn.commit()
            
            return {
                'success': True,
                'products_processed': len(products),
                'recommendations_generated': total_recommendations
            }
            
        except Exception as e:
            conn.rollback()
            return {
                'success': False,
                'error': str(e)
            }
        finally:
            cursor.close()
            conn.close()


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def calculate_recommendation_score(views, purchases, co_purchases=0):
    """
    Calculate a recommendation score based on multiple factors
    
    Args:
        views (int): Number of views
        purchases (int): Number of purchases
        co_purchases (int): Number of co-purchases with other products
        
    Returns:
        int: Score from 0-100
    """
    # Weighted scoring
    score = (purchases * 50) + (co_purchases * 30) + (views * 1)
    
    # Normalize to 0-100
    max_possible = 10000  # Assumed maximum
    normalized = min(100, int((score / max_possible) * 100))
    
    return normalized
