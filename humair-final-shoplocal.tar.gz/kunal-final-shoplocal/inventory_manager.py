"""
Advanced Inventory Management for ShopLocal
Week 4 – Inventory Features
"""

from datetime import datetime, timedelta
import pymysql


class InventoryManager:
    def __init__(self, db_config):
        self.db_config = db_config

    # ---------------------------------------------------------------------
    # DB CONNECTION
    # ---------------------------------------------------------------------
    def get_connection(self):
        return pymysql.connect(
            host=self.db_config["host"],
            user=self.db_config["user"],
            password=self.db_config["password"],
            database=self.db_config["database"],
            port=self.db_config.get("port", 3306),
            cursorclass=pymysql.cursors.DictCursor,
        )

    # ---------------------------------------------------------------------
    # LOW STOCK
    # ---------------------------------------------------------------------
    def get_low_stock_products(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT id, name, category, stock, low_stock_threshold
                FROM products
                WHERE stock <= low_stock_threshold
                  AND status = 'active'
            """)
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()

    # ---------------------------------------------------------------------
    # SALES VELOCITY
    # ---------------------------------------------------------------------
    def calculate_sales_velocity(self, product_id, days=30):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT SUM(oi.quantity) AS total_sold
                FROM order_items oi
                JOIN orders o ON oi.order_id = o.id
                WHERE oi.product_id = %s
                  AND o.created_at >= DATE_SUB(NOW(), INTERVAL %s DAY)
                  AND o.status != 'cancelled'
            """, (product_id, days))

            row = cursor.fetchone()
            total = row["total_sold"] or 0
            return float(total) / float(days) if days > 0 else 0
        finally:
            cursor.close()
            conn.close()

    # ---------------------------------------------------------------------
    # FORECAST STOCKOUT
    # ---------------------------------------------------------------------
    def forecast_stockout_date(self, product_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT id, name, stock, low_stock_threshold
                FROM products WHERE id = %s
            """, (product_id,))
            product = cursor.fetchone()

            if not product:
                return None

            daily_sales = float(self.calculate_sales_velocity(product_id))
            current_stock = float(product["stock"])

            if daily_sales <= 0:
                return {
                    "product_id": product_id,
                    "product_name": product["name"],
                    "daily_sales": 0,
                    "status": "no_sales_data",
                    "days_until_stockout": None,
                    "stockout_date": None,
                }

            days_left = current_stock / daily_sales

            return {
                "product_id": product_id,
                "product_name": product["name"],
                "daily_sales": round(daily_sales, 2),
                "current_stock": current_stock,
                "days_until_stockout": int(days_left),
                "stockout_date": (
                    datetime.now() + timedelta(days=int(days_left))
                ).strftime("%Y-%m-%d"),
                "status": "critical" if days_left <= 7 else "warning"
            }
        finally:
            cursor.close()
            conn.close()

    # ---------------------------------------------------------------------
    # REORDER POINT
    # ---------------------------------------------------------------------
    def calculate_reorder_point(self, product_id, lead_time_days=7, safety_stock_days=3):
        daily_sales = float(self.calculate_sales_velocity(product_id))

        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT stock FROM products WHERE id = %s", (product_id,))
            row = cursor.fetchone()
            current_stock = float(row["stock"]) if row else 0
        finally:
            cursor.close()
            conn.close()

        if daily_sales <= 0:
            return {
                "product_id": product_id,
                "daily_sales": 0,
                "current_stock": current_stock,
                "reorder_point": 0,
                "needs_reorder": False,
                "status": "no_sales_data"
            }

        reorder_point = daily_sales * (lead_time_days + safety_stock_days)
        needs_reorder = current_stock <= reorder_point

        return {
            "product_id": product_id,
            "daily_sales": round(daily_sales, 2),
            "current_stock": current_stock,
            "reorder_point": round(reorder_point, 2),
            "needs_reorder": needs_reorder,
            "suggested_order_quantity": int(reorder_point * 2),
            "status": "reorder_required" if needs_reorder else "stock_ok"
        }

    # ---------------------------------------------------------------------
    # INVENTORY VALUE
    # ---------------------------------------------------------------------
    def get_inventory_value(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT
                    SUM(stock * price) AS total_value,
                    SUM(stock) AS total_units
                FROM products
                WHERE status = 'active'
            """)
            row = cursor.fetchone()
            return {
                "total_units": row["total_units"] or 0,
                "total_value": float(row["total_value"] or 0)
            }
        finally:
            cursor.close()
            conn.close()

    # ---------------------------------------------------------------------
    # INVENTORY TURNOVER
    # ---------------------------------------------------------------------
    def calculate_inventory_turnover(self, days=30):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT SUM(oi.quantity) AS sold
                FROM order_items oi
                JOIN orders o ON oi.order_id = o.id
                WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL %s DAY)
                  AND o.status != 'cancelled'
            """, (days,))
            sold = float((cursor.fetchone()["sold"] or 0))
            return round(sold / days, 2) if days > 0 else 0
        finally:
            cursor.close()
            conn.close()

    # ---------------------------------------------------------------------
    # STOCK MOVEMENT
    # ---------------------------------------------------------------------
    def get_stock_movement_report(self, days=30):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT product_id,
                       SUM(quantity_change) AS net_change,
                       COUNT(*) AS movements
                FROM inventory_log
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL %s DAY)
                GROUP BY product_id
            """, (days,))
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()

    # ---------------------------------------------------------------------
    # INVENTORY ALERTS (MAIN API)
    # ---------------------------------------------------------------------
    def generate_inventory_alerts(self):
        alerts = {
            "critical": [],
            "warning": [],
            "reorder": [],
            "forecast": []
        }

        low_stock = self.get_low_stock_products()

        for p in low_stock:
            if p["stock"] == 0:
                alerts["critical"].append(p)
            else:
                alerts["warning"].append(p)

        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT id, name FROM products WHERE status='active'")
            products = cursor.fetchall()

            for p in products:
                reorder = self.calculate_reorder_point(p["id"])
                if reorder["needs_reorder"]:
                    alerts["reorder"].append(reorder)

                forecast = self.forecast_stockout_date(p["id"])
                if forecast and forecast["status"] in ("critical", "warning"):
                    alerts["forecast"].append(forecast)
        finally:
            cursor.close()
            conn.close()

        return alerts

