# app.py
import os
import uuid
from decimal import Decimal
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, jsonify, current_app, send_from_directory
)
from flask_cors import CORS
import pymysql
import pymysql.cursors
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from recommendation_engine import RecommendationEngine
from inventory_manager import InventoryManager

# ========== Configuration (env-friendly) ==========
APP_PORT = int(os.environ.get("PORT", 8080))
APP_HOST = os.environ.get("HOST", "0.0.0.0")
DEBUG = os.environ.get("FLASK_DEBUG", "False").lower() in ("1", "true", "yes")

SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")

DB_HOST = os.environ.get("DB_HOST", "l2-db.c5s6ma0caqgt.ap-south-1.rds.amazonaws.com")
DB_USER = os.environ.get("DB_USER", "nixace")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "nixdevops")
DB_NAME = os.environ.get("DB_NAME", "shoplocal")
DB_PORT = int(os.environ.get("DB_PORT", 3306))

AWS_S3_BUCKET = os.environ.get('AWS_S3_BUCKET', '')
AWS_REGION = os.environ.get('AWS_REGION', 'ap-south-1')
USE_S3 = bool(AWS_S3_BUCKET)

UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

# Ensure upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ========== Flask app ==========
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = SECRET_KEY
CORS(app)
# ================== Recommendation Engine ==================
recommendation_engine = RecommendationEngine(
    db_config={
        "host": DB_HOST,
        "user": DB_USER,
        "password": DB_PASSWORD,
        "database": DB_NAME,
        "port": DB_PORT,
    }
)
# ================== Inventory Manager ==================
inventory_manager = InventoryManager(
    db_config={
        "host": DB_HOST,
        "user": DB_USER,
        "password": DB_PASSWORD,
        "database": DB_NAME,
        "port": DB_PORT,
    }
)

# Serve uploaded files (simple)
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

# ========== Database helper ==========
def get_db_connection():
    """
    Return a new pymysql connection with DictCursor.
    Caller must close the connection.
    """
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        port=DB_PORT,
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,  # we manage transactions explicitly
    )

# ========== Utilities ==========
def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_image(file_storage):
    """Save uploaded file to UPLOAD_FOLDER and return public URL path."""
    if not file_storage or file_storage.filename == '':
        return None
    if not allowed_file(file_storage.filename):
        return None
    filename = secure_filename(file_storage.filename)
    # make filename unique to avoid collisions
    name, ext = os.path.splitext(filename)
    unique = f"{name}_{uuid.uuid4().hex[:8]}{ext}"
    filepath = os.path.join(UPLOAD_FOLDER, unique)
    file_storage.save(filepath)
    # return URL path used in templates: /uploads/<filename>
    return url_for('uploaded_file', filename=unique)

def generate_order_number() -> str:
    timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
    random_str = str(uuid.uuid4())[:6].upper()
    return f"SL-{timestamp}-{random_str}"

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Please login to access admin panel', 'error')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated

# update_inventory supports being called with an existing transaction (conn/cursor)
def update_inventory(product_id, quantity_change, change_type,
                     reference_type=None, reference_id=None, notes=None,
                     conn=None, cursor=None):
    """
    Update product stock and log the inventory change.
    If conn/cursor provided, use them (useful for transactional flows). Otherwise create/close connection.
    Returns True on success, False on any failure (does not raise).
    """
    try:
        product_id = int(product_id)
    except Exception:
        current_app.logger.exception("Invalid product_id in update_inventory: %s", product_id)
        return False

    close_conn = False
    if conn is None or cursor is None:
        conn = get_db_connection()
        cursor = conn.cursor()
        close_conn = True

    try:
        # Lock the row to prevent race conditions (for transactional updates)
        cursor.execute("SELECT stock FROM products WHERE id = %s FOR UPDATE", (product_id,))
        row = cursor.fetchone()
        if not row:
            # product doesn't exist
            if close_conn:
                conn.rollback()
            return False

        previous_stock = row['stock']
        new_stock = previous_stock + int(quantity_change)

        if new_stock < 0:
            # not enough stock
            if close_conn:
                conn.rollback()
            return False

        cursor.execute("UPDATE products SET stock = %s WHERE id = %s", (new_stock, product_id))

        admin_id = session.get('admin_id')

        cursor.execute('''
            INSERT INTO inventory_log
            (product_id, change_type, quantity_change, previous_stock, new_stock,
            reference_type, reference_id, notes, created_by, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        ''', (product_id, change_type, quantity_change, previous_stock, new_stock,
            reference_type, reference_id, notes, admin_id))

        # status updates
        if new_stock == 0:
            cursor.execute("UPDATE products SET status = %s WHERE id = %s", ('out_of_stock', product_id))
        elif previous_stock == 0 and new_stock > 0:
            cursor.execute("UPDATE products SET status = %s WHERE id = %s", ('active', product_id))

        if close_conn:
            conn.commit()
        return True
    except Exception:
        current_app.logger.exception("Error updating inventory for product_id=%s", product_id)
        if close_conn:
            conn.rollback()
        return False
    finally:
        if close_conn:
            cursor.close()
            conn.close()

# Template filter for currency
@app.template_filter('currency')
def currency_filter(value):
    try:
        return f"₹{float(value):,.2f}"
    except Exception:
        return f"₹{value}"

# Convert Decimal objects for JSON responses
def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [decimal_to_float(v) for v in obj]
    return obj

# ========== Routes: Web ==========
@app.route('/')
def home():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        category = request.args.get('category')
        if category:
            cursor.execute('SELECT * FROM products WHERE category = %s AND status = %s ORDER BY created_at DESC', (category, 'active'))
        else:
            cursor.execute('SELECT * FROM products WHERE status = %s ORDER BY created_at DESC', ('active',))
        products = cursor.fetchall()

        cursor.execute('SELECT DISTINCT category FROM products WHERE status = %s ORDER BY category', ('active',))
        categories = [r['category'] for r in cursor.fetchall()]
        return render_template('home.html', products=products, categories=categories, current_category=category)
    except Exception:
        current_app.logger.exception("Error in home route")
        flash('Something went wrong loading products', 'error')
        return render_template('home.html', products=[], categories=[], current_category=None)
    finally:
        cursor.close()
        conn.close()

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT * FROM products WHERE id = %s', (product_id,))
        product = cursor.fetchone()
        if not product:
            flash('Product not found', 'error')
            return redirect(url_for('home'))

        # update views and log view (best-effort)
        try:
            cursor.execute('UPDATE products SET views = views + 1 WHERE id = %s', (product_id,))
            session_id = session.get('session_id', str(uuid.uuid4()))
            session['session_id'] = session_id
            cursor.execute('INSERT INTO product_views (product_id, session_id, ip_address, created_at) VALUES (%s, %s, %s, NOW())',
                           (product_id, session_id, request.remote_addr))
            conn.commit()
        except Exception:
            conn.rollback()
            current_app.logger.exception("Could not update views/product_views (non-fatal)")

        # recommendations
        cursor.execute('''
            SELECT p.* FROM products p
            INNER JOIN product_recommendations pr ON p.id = pr.recommended_product_id
            WHERE pr.product_id = %s AND p.status = %s
            ORDER BY pr.score DESC LIMIT 4
        ''', (product_id, 'active'))
        recommendations = cursor.fetchall()
        return render_template('product.html', product=product, recommendations=recommendations)
    finally:
        cursor.close()
        conn.close()

@app.route('/cart')
def view_cart():
    cart = session.get('cart', {})
    cart_items = []
    total = Decimal('0.00')

    if cart:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            for product_id_str, quantity in cart.items():
                try:
                    product_id = int(product_id_str)
                except Exception:
                    continue
                cursor.execute('SELECT * FROM products WHERE id = %s', (product_id,))
                product = cursor.fetchone()
                if product and product.get('status') == 'active':
                    item_total = Decimal(str(product['price'])) * int(quantity)
                    cart_items.append({
                        'product': product,
                        'quantity': int(quantity),
                        'item_total': item_total
                    })
                    total += item_total
        finally:
            cursor.close()
            conn.close()
    return render_template('cart.html', cart_items=cart_items, total=total)

@app.route('/add-to-cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    quantity = int(request.form.get('quantity', 1))
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT * FROM products WHERE id = %s AND status = %s', (product_id, 'active'))
        product = cursor.fetchone()
    finally:
        cursor.close()
        conn.close()

    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('home'))

    if product['stock'] < quantity:
        flash(f'Only {product["stock"]} items available', 'error')
        return redirect(url_for('product_detail', product_id=product_id))

    cart = session.get('cart', {})
    pid_str = str(product_id)
    if pid_str in cart:
        new_qty = cart[pid_str] + quantity
        if product['stock'] < new_qty:
            flash(f'Cannot add more. Only {product["stock"]} items available', 'error')
            return redirect(url_for('product_detail', product_id=product_id))
        cart[pid_str] = new_qty
    else:
        cart[pid_str] = quantity

    session['cart'] = cart
    flash(f'{product["name"]} added to cart!', 'success')
    return redirect(url_for('view_cart'))

@app.route('/update-cart/<int:product_id>', methods=['POST'])
def update_cart(product_id):
    quantity = int(request.form.get('quantity', 1))
    cart = session.get('cart', {})
    pid_str = str(product_id)
    if quantity > 0:
        cart[pid_str] = quantity
    else:
        cart.pop(pid_str, None)
    session['cart'] = cart
    flash('Cart updated', 'success')
    return redirect(url_for('view_cart'))

@app.route('/remove-from-cart/<int:product_id>')
def remove_from_cart(product_id):
    cart = session.get('cart', {})
    cart.pop(str(product_id), None)
    session['cart'] = cart
    flash('Item removed from cart', 'success')
    return redirect(url_for('view_cart'))

@app.route('/checkout')
def checkout():
    cart = session.get('cart', {})
    if not cart:
        flash('Your cart is empty', 'error')
        return redirect(url_for('home'))

    cart_items = []
    total = Decimal('0.00')
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        for product_id_str, quantity in cart.items():
            try:
                product_id = int(product_id_str)
            except Exception:
                continue
            cursor.execute('SELECT * FROM products WHERE id = %s', (product_id,))
            product = cursor.fetchone()
            if product:
                item_total = Decimal(str(product['price'])) * int(quantity)
                cart_items.append({
                    'product': product,
                    'quantity': int(quantity),
                    'item_total': item_total
                })
                total += item_total
    finally:
        cursor.close()
        conn.close()

    return render_template('checkout.html', cart_items=cart_items, total=total)

# ======= PLACE ORDER (Transactional, safe) ========
@app.route('/place-order', methods=['POST'])
def place_order():
    cart = session.get('cart', {})
    if not cart:
        flash('Your cart is empty', 'error')
        return redirect(url_for('home'))

    customer_name = request.form.get('customer_name')
    customer_email = request.form.get('customer_email')
    customer_phone = request.form.get('customer_phone')
    shipping_address = request.form.get('shipping_address', '')

    if not all([customer_name, customer_email, customer_phone]):
        flash('Please fill all required fields', 'error')
        return redirect(url_for('checkout'))

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Start transaction
        order_total = Decimal('0.00')
        order_items = []

        # Validate stock and collect items
        for product_id_str, qty in cart.items():
            try:
                product_id = int(product_id_str)
                quantity = int(qty)
            except Exception:
                conn.rollback()
                flash('Invalid product in cart', 'error')
                return redirect(url_for('view_cart'))

            cursor.execute('SELECT * FROM products WHERE id = %s FOR UPDATE', (product_id,))
            product = cursor.fetchone()
            if not product or product.get('status') != 'active' or product['stock'] < quantity:
                conn.rollback()
                flash('Unable to process order. Please check product availability.', 'error')
                return redirect(url_for('view_cart'))

            subtotal = Decimal(str(product['price'])) * quantity
            order_total += subtotal
            order_items.append({
                'product_id': product_id,
                'product_name': product['name'],
                'quantity': quantity,
                'price': product['price'],
                'subtotal': subtotal
            })

        # Create order
        order_number = generate_order_number()
        cursor.execute('''
            INSERT INTO orders
            (order_number, customer_name, customer_email, customer_phone, total_amount, status, payment_status, shipping_address, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
        ''', (order_number, customer_name, customer_email, customer_phone, order_total, 'confirmed', 'paid', shipping_address))
        order_id = cursor.lastrowid

        # Create order items and update inventory (within same transaction)
        for item in order_items:
            cursor.execute('''
                INSERT INTO order_items
                (order_id, product_id, product_name, quantity, price, subtotal, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
            ''', (order_id, item['product_id'], item['product_name'], item['quantity'], item['price'], item['subtotal']))

            # use named args to avoid positional mistakes
            success = update_inventory(
                item['product_id'],
                -item['quantity'],
                'sale',
                reference_type='order',
                reference_id=order_id,
                notes=f"Order {order_number}",
                conn=conn,
                cursor=cursor
            )
            if not success:
                conn.rollback()
                flash('Failed to update inventory. Order cancelled.', 'error')
                return redirect(url_for('view_cart'))

            cursor.execute('UPDATE products SET purchases = purchases + %s WHERE id = %s', (item['quantity'], item['product_id']))

        conn.commit()

        # Clear cart
        session.pop('cart', None)
        flash(f'Order {order_number} placed successfully!', 'success')
        return redirect(url_for('order_confirmation', order_id=order_id))
    except Exception:
        conn.rollback()
        current_app.logger.exception("Error placing order")
        flash('An error occurred while placing your order. Please try again.', 'error')
        return redirect(url_for('view_cart'))
    finally:
        cursor.close()
        conn.close()

@app.route('/order/<int:order_id>')
def order_confirmation(order_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT * FROM orders WHERE id = %s', (order_id,))
        order = cursor.fetchone()
        if not order:
            flash('Order not found', 'error')
            return redirect(url_for('home'))

        cursor.execute('SELECT * FROM order_items WHERE order_id = %s', (order_id,))
        order_items = cursor.fetchall()

        return render_template('order_confirmation.html', order=order, order_items=order_items)
    finally:
        cursor.close()
        conn.close()

# ========== REST API ==========
@app.route('/api/home', methods=['GET'])
def api_home():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT * FROM products WHERE status = %s ORDER BY created_at DESC LIMIT 20",
            ('active',)
        )
        products = cursor.fetchall()

        cursor.execute(
            "SELECT DISTINCT category FROM products WHERE status = %s ORDER BY category",
            ('active',)
        )
        categories = [row['category'] for row in cursor.fetchall()]

        for p in products:
            if 'price' in p:
                p['price'] = float(p['price'])

        return jsonify({
            "success": True,
            "products": products,
            "categories": categories
        })
    finally:
        cursor.close()
        conn.close()

@app.route('/api/recommendations/<int:product_id>', methods=['GET'])
def api_recommendations(product_id):
    try:
        recommendations = recommendation_engine.get_recommendations(
            product_id=product_id,
            limit=4
        )

        # Convert Decimal → float (JSON safe)
        for r in recommendations:
            if 'price' in r:
                r['price'] = float(r['price'])

        return jsonify({
            "success": True,
            "recommendations": recommendations
        })
    except Exception:
        current_app.logger.exception("Recommendation API failed")
        return jsonify({
            "success": False,
            "recommendations": []
        }), 500

@app.route("/api/trending", methods=["GET"])
def api_trending_products():
    try:
        data = recommendation_engine.get_trending_products(limit=10)

        for p in data:
            if 'price' in p:
                p['price'] = float(p['price'])

        return jsonify({
            "success": True,
            "products": data
        })
    except Exception:
        current_app.logger.exception("Trending API failed")
        return jsonify({
            "success": False,
            "error": "Failed to fetch trending products"
        }), 500

@app.route("/api/inventory/forecast/<int:product_id>", methods=["GET"])
def api_inventory_forecast_public(product_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(
            "SELECT id, name, stock FROM products WHERE id = %s",
            (product_id,)
        )
        product = cursor.fetchone()

        cursor.close()
        conn.close()

        if not product:
            return jsonify({
                "success": False,
                "error": "Product not found"
            }), 404

        daily_sales = inventory_manager.calculate_sales_velocity(product_id)

        forecast = inventory_manager.forecast_stockout_date(product_id)
        days_left = forecast.get("days_until_stockout")

        reorder_point = inventory_manager.calculate_reorder_point(product_id)

        return jsonify({
            "success": True,
            "product_id": product["id"],
            "product_name": product["name"],
            "current_stock": product["stock"],
            "daily_sales": round(daily_sales, 2),
            "days_until_stockout": days_left,
            "reorder_point": reorder_point
        })

    except Exception:
        current_app.logger.exception("Public inventory forecast API failed")
        return jsonify({
            "success": False,
            "error": "Failed to calculate inventory forecast"
        }), 500

@app.route("/api/inventory/low-stock", methods=["GET"])
def api_inventory_low_stock():
    try:
        data = inventory_manager.get_low_stock_products()
        return jsonify({
            "success": True,
            "products": data
        })
    except Exception:
        current_app.logger.exception("Low stock API failed")
        return jsonify({
            "success": False,
            "error": "Failed to fetch low stock products"
        }), 500

@app.route("/api/inventory/velocity/<int:product_id>", methods=["GET"])
def api_inventory_velocity(product_id):
    try:
        velocity = inventory_manager.calculate_sales_velocity(product_id)
        return jsonify({
            "success": True,
            "product_id": product_id,
            "daily_sales": round(velocity, 2)
        })
    except Exception:
        current_app.logger.exception("Sales velocity API failed")
        return jsonify({
            "success": False,
            "error": "Failed to calculate sales velocity"
        }), 500

@app.route("/api/inventory/value", methods=["GET"])
def api_inventory_value():
    try:
        value = inventory_manager.get_inventory_value()
        return jsonify({
            "success": True,
            "inventory": value
        })
    except Exception:
        current_app.logger.exception("Inventory value API failed")
        return jsonify({
            "success": False,
            "error": "Failed to fetch inventory value"
        }), 500

@app.route("/api/inventory/turnover", methods=["GET"])
def api_inventory_turnover():
    try:
        days = int(request.args.get("days", 30))
        turnover = inventory_manager.calculate_inventory_turnover(days)
        return jsonify({
            "success": True,
            "days": days,
            "turnover": turnover
        })
    except Exception:
        current_app.logger.exception("Inventory turnover API failed")
        return jsonify({
            "success": False,
            "error": "Failed to calculate inventory turnover"
        }), 500


@app.route('/api/categories', methods=['GET'])
def api_categories():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT DISTINCT category FROM products WHERE status = %s ORDER BY category",
            ('active',)
        )
        categories = [row['category'] for row in cursor.fetchall()]

        return jsonify({
            "success": True,
            "categories": categories
        })
    finally:
        cursor.close()
        conn.close()


@app.route('/api/products', methods=['GET'])
def api_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        category = request.args.get('category')
        if category:
            cursor.execute('SELECT * FROM products WHERE category = %s AND status = %s ORDER BY created_at DESC', (category, 'active'))
        else:
            cursor.execute('SELECT * FROM products WHERE status = %s ORDER BY created_at DESC', ('active',))
        products = cursor.fetchall()
        # convert Decimal to float
        for p in products:
            if 'price' in p:
                p['price'] = float(p['price'])
        return jsonify({'success': True, 'products': products})
    finally:
        cursor.close()
        conn.close()

@app.route('/api/product/<int:product_id>', methods=['GET'])
def api_product_detail(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT * FROM products WHERE id = %s', (product_id,))
        product = cursor.fetchone()
        if not product:
            return jsonify({'success': False, 'error': 'Product not found'}), 404
        if 'price' in product:
            product['price'] = float(product['price'])

        cursor.execute('''
            SELECT p.* FROM products p
            INNER JOIN product_recommendations pr ON p.id = pr.recommended_product_id
            WHERE pr.product_id = %s AND p.status = %s
            ORDER BY pr.score DESC LIMIT 4
        ''', (product_id, 'active'))
        recs = cursor.fetchall()
        for r in recs:
            if 'price' in r:
                r['price'] = float(r['price'])

        return jsonify({'success': True, 'product': product, 'recommendations': recs})
    finally:
        cursor.close()
        conn.close()

@app.route('/api/order', methods=['POST'])
def api_create_order():
    data = request.get_json() or {}
    items = data.get('items')
    if not items:
        return jsonify({'success': False, 'error': 'No items in order'}), 400

    customer_name = data.get('customer_name')
    customer_email = data.get('customer_email')
    customer_phone = data.get('customer_phone')
    shipping_address = data.get('shipping_address', '')

    if not all([customer_name, customer_email, customer_phone]):
        return jsonify({'success': False, 'error': 'Missing required fields'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        total = Decimal('0.00')
        order_items = []
        # validate and compute
        for it in items:
            try:
                pid = int(it.get('product_id'))
                qty = int(it.get('quantity', 1))
            except Exception:
                return jsonify({'success': False, 'error': 'Invalid item format'}), 400

            cursor.execute('SELECT * FROM products WHERE id = %s FOR UPDATE', (pid,))
            product = cursor.fetchone()
            if not product or product.get('stock') < qty:
                conn.rollback()
                return jsonify({'success': False, 'error': f'Product {pid} not available'}), 400

            subtotal = Decimal(str(product['price'])) * qty
            total += subtotal
            order_items.append({'product_id': pid, 'product_name': product['name'], 'quantity': qty, 'price': product['price'], 'subtotal': subtotal})

        order_number = generate_order_number()
        cursor.execute('''
            INSERT INTO orders
            (order_number, customer_name, customer_email, customer_phone, total_amount, status, payment_status, shipping_address, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
        ''', (order_number, customer_name, customer_email, customer_phone, total, 'confirmed', 'paid', shipping_address))
        order_id = cursor.lastrowid

        for item in order_items:
            cursor.execute('''
                INSERT INTO order_items
                (order_id, product_id, product_name, quantity, price, subtotal, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
            ''', (order_id, item['product_id'], item['product_name'], item['quantity'], item['price'], item['subtotal']))
            ok = update_inventory(
                item['product_id'],
                -item['quantity'],
                'sale',
                reference_type='order',
                reference_id=order_id,
                notes=f"Order {order_number}",
                conn=conn,
                cursor=cursor
            )
            if not ok:
                conn.rollback()
                return jsonify({'success': False, 'error': 'Failed to update inventory'}), 500

        conn.commit()
        return jsonify({'success': True, 'order_id': order_id, 'order_number': order_number, 'total': float(total)})
    except Exception:
        conn.rollback()
        current_app.logger.exception("API order creation failed")
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    finally:
        cursor.close()
        conn.close()




# ========== Admin routes ==========
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT * FROM admin_users WHERE username = %s AND is_active = TRUE', (username,))
            admin = cursor.fetchone()
            if admin and check_password_hash(admin.get('password_hash', ''), password):
                session['admin_id'] = admin['id']
                session['admin_username'] = admin['username']
                session['admin_role'] = admin.get('role')
                cursor.execute('UPDATE admin_users SET last_login = NOW() WHERE id = %s', (admin['id'],))
                conn.commit()
                flash('Login successful!', 'success')
                return redirect(url_for('admin_dashboard'))
            else:
                flash('Invalid username or password', 'error')
        finally:
            cursor.close()
            conn.close()
    return render_template('admin/login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    session.pop('admin_username', None)
    session.pop('admin_role', None)
    flash('Logged out successfully', 'success')
    return redirect(url_for('admin_login'))

@app.route('/admin')
@admin_required
def admin_dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('SELECT COUNT(*) as count FROM products WHERE status = %s', ('active',))
        total_products = cursor.fetchone().get('count', 0)

        # if low_stock_threshold not a column, this query may fail in your DB schema.
        # To be safe, use a numeric threshold value if schema does not have column.
        try:
            cursor.execute('SELECT COUNT(*) as count FROM products WHERE stock <= low_stock_threshold AND status = %s', ('active',))
            low_stock_count = cursor.fetchone().get('count', 0)
        except Exception:
            # fallback to threshold value 5 if low_stock_threshold column is absent
            cursor.execute('SELECT COUNT(*) as count FROM products WHERE stock <= %s AND status = %s', (5, 'active'))
            low_stock_count = cursor.fetchone().get('count', 0)

        cursor.execute('SELECT COUNT(*) as count FROM orders WHERE status != %s', ('cancelled',))
        total_orders = cursor.fetchone().get('count', 0)

        cursor.execute('SELECT SUM(total_amount) as revenue FROM orders WHERE payment_status = %s', ('paid',))
        total_revenue = cursor.fetchone().get('revenue') or 0

        cursor.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT 10')
        recent_orders = cursor.fetchall()

        try:
            cursor.execute('SELECT * FROM products WHERE stock <= low_stock_threshold AND status = %s ORDER BY stock ASC LIMIT 10', ('active',))
            low_stock_products = cursor.fetchall()
        except Exception:
            cursor.execute('SELECT * FROM products WHERE stock <= %s AND status = %s ORDER BY stock ASC LIMIT 10', (5, 'active'))
            low_stock_products = cursor.fetchall()

        stats = {
            'total_products': total_products,
            'low_stock_count': low_stock_count,
            'total_orders': total_orders,
            'total_revenue': float(total_revenue)
        }
        return render_template('admin/dashboard.html', stats=stats, recent_orders=recent_orders, low_stock_products=low_stock_products)
    finally:
        cursor.close()
        conn.close()

# Admin Orders
@app.route('/admin/orders')
@admin_required
def admin_orders():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM orders ORDER BY created_at DESC")
        orders = cursor.fetchall()
        return render_template("admin/orders.html", orders=orders)
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/orders/<int:order_id>')
@admin_required
def admin_order_detail(order_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM orders WHERE id = %s", (order_id,))
        order = cursor.fetchone()

        if not order:
            flash("Order not found", "error")
            return redirect(url_for("admin_orders"))

        cursor.execute("SELECT * FROM order_items WHERE order_id = %s", (order_id,))
        items = cursor.fetchall()

        return render_template("admin/order_detail.html", order=order, items=items)
    finally:
        cursor.close()
        conn.close()

# Inventory log
@app.route('/admin/inventory')
@admin_required
def admin_inventory():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT il.*, p.name AS product_name
            FROM inventory_log il
            LEFT JOIN products p ON il.product_id = p.id
            ORDER BY il.created_at DESC
            LIMIT 200
        """)
        logs = cursor.fetchall()
        return render_template("admin/inventory.html", logs=logs)
    finally:
        cursor.close()
        conn.close()

# Inventory Analytics (Week 4
@app.route('/admin/inventory/analytics')
@admin_required
def admin_inventory_analytics():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # 1️⃣ Inventory Health (from VIEW)
        cursor.execute("SELECT * FROM v_inventory_health ORDER BY status")
        inventory_health = cursor.fetchall()

        # 2️⃣ Low stock alerts (from table)
        cursor.execute("""
            SELECT ia.*, p.name AS product_name
            FROM inventory_alerts ia
            JOIN products p ON ia.product_id = p.id
            WHERE ia.is_resolved = 0
            ORDER BY ia.created_at DESC
        """)
        alerts = cursor.fetchall()

        # 3️⃣ Sales velocity (calculated dynamically)
        sales_velocity = []
        for item in inventory_health:
            velocity = inventory_manager.calculate_sales_velocity(item["id"])
            sales_velocity.append({
                "product_id": item["id"],
                "name": item["name"],
                "daily_sales": round(velocity, 2)
            })

        # 4️⃣ Forecast (calculated dynamically – NO DB)
        forecasts = []
        for item in inventory_health:
            forecast = inventory_manager.forecast_stockout_date(item["id"])
            if forecast:
                forecasts.append(forecast)

        return render_template(
            "admin/inventory_analytics.html",
            inventory_health=inventory_health,
            alerts=alerts,
            sales_velocity=sales_velocity,
            forecasts=forecasts
        )

    finally:
        cursor.close()
        conn.close()

# ========== Admin Products CRUD ==========
@app.route('/admin/products')
@admin_required
def admin_products():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM products ORDER BY created_at DESC")
        products = cursor.fetchall()
        return render_template("admin/products.html", products=products)
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/products/add', methods=['GET', 'POST'])
@admin_required
def admin_add_product():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        if request.method == "POST":
            name = request.form.get("name")
            description = request.form.get("description", "")
            price = request.form.get("price", "0")
            category = request.form.get("category", "")
            stock = request.form.get("stock", 0)
            low_stock_threshold = request.form.get("low_stock_threshold", 5)
            status = request.form.get("status", "active")

            # Handle image upload (optional)
            image = request.files.get("image")
            image_url = None
            if image and allowed_file(image.filename):
                image_url = save_uploaded_image(image)

            # ✅ FIXED: removed created_at from INSERT
            cursor.execute("""
                INSERT INTO products 
                (name, description, price, category, stock, low_stock_threshold, image_url, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (name, description, price, category, stock, low_stock_threshold, image_url, status))

            conn.commit()
            flash("Product added successfully", "success")
            return redirect(url_for('admin_products'))

        # GET - show blank form
        return render_template("admin/product_form.html", product=None)

    finally:
        cursor.close()
        conn.close()

@app.route('/admin/products/edit/<int:product_id>', methods=['GET', 'POST'])
@admin_required
def admin_edit_product(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
        product = cursor.fetchone()
        if not product:
            flash("Product not found", "error")
            return redirect(url_for('admin_products'))

        if request.method == "POST":
            name = request.form.get("name")
            description = request.form.get("description", "")
            price = request.form.get("price", product.get("price"))
            category = request.form.get("category", product.get("category"))
            stock = request.form.get("stock", product.get("stock"))
            low_stock_threshold = request.form.get("low_stock_threshold", product.get("low_stock_threshold") or 5)
            status = request.form.get("status", product.get("status", "active"))

            # Image handling
            image = request.files.get("image")
            image_url = product.get("image_url")
            if image and allowed_file(image.filename):
                image_url = save_uploaded_image(image)

            cursor.execute("""
                UPDATE products
                SET name=%s, description=%s, price=%s, category=%s, stock=%s, low_stock_threshold=%s, image_url=%s, status=%s, updated_at=NOW()
                WHERE id = %s
            """, (name, description, price, category, stock, low_stock_threshold, image_url, status, product_id))
            conn.commit()
            flash("Product updated successfully", "success")
            return redirect(url_for('admin_products'))

        # GET - show form populated
        return render_template("admin/product_form.html", product=product)
    finally:
        cursor.close()
        conn.close()

@app.route('/admin/products/delete/<int:product_id>', methods=['POST'])
@admin_required
def admin_delete_product(product_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Soft delete: mark inactive OR hard delete depending on preference
        # Here we'll soft-delete by setting status = 'inactive' to be safer.
        cursor.execute("UPDATE products SET status = %s WHERE id = %s", ('inactive', product_id))
        conn.commit()
        flash("Product marked inactive (deleted)", "success")
        return redirect(url_for('admin_products'))
    except Exception:
        conn.rollback()
        current_app.logger.exception("Failed to delete product id=%s", product_id)
        flash("Failed to delete product", "error")
        return redirect(url_for('admin_products'))
    finally:
        cursor.close()
        conn.close()

# ========== Misc & Health ==========
@app.route('/health')
def health_check():
    try:
        conn = get_db_connection()
        conn.close()
        return jsonify({'status': 'healthy', 'database': 'connected'}), 200
    except Exception as e: 
        current_app.logger.exception("Health check failed")
        return jsonify({'status': 'unhealthy', 'error': str(e)}), 500
# =========================================================
# WEEK 4 – INVENTORY MANAGEMENT APIs (ADMIN)
# =========================================================

@app.route("/api/admin/inventory/alerts")
def api_inventory_alerts():
    data = inventory_manager.generate_inventory_alerts()
    return jsonify(decimal_to_float(data))


@app.route("/api/admin/inventory/forecast/<int:product_id>")
def api_inventory_forecast(product_id):
    data = inventory_manager.forecast_stockout_date(product_id)
    return jsonify(decimal_to_float(data))


@app.route("/api/admin/inventory/reorder/<int:product_id>")
def api_inventory_reorder(product_id):
    data = inventory_manager.calculate_reorder_point(product_id)
    return jsonify(decimal_to_float(data))


@app.route("/api/admin/inventory/summary")
def api_inventory_summary():
    data = {
        "inventory_value": inventory_manager.get_inventory_value(),
        "inventory_turnover": inventory_manager.calculate_inventory_turnover(days=30)
    }
    return jsonify(decimal_to_float(data))


@app.route("/api/admin/inventory/movement")
def api_inventory_movement():
    data = inventory_manager.get_stock_movement_report(days=30)
    return jsonify(decimal_to_float(data))


@app.errorhandler(404)
def not_found(e):
    if request.path.startswith('/api/'):
        return jsonify({
            "success": False,
            "error": "API endpoint not found"
        }), 404
    return render_template('404.html'), 404 


@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500


# ======= About page =======
@app.route('/about')
def about():
    return render_template('about.html')

# ========== Run app (only when executed directly) ==========
if __name__ == '__main__':
    app.run(host=APP_HOST, port=APP_PORT, debug=DEBUG)

































